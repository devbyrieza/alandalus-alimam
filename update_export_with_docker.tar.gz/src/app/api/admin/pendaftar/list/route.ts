import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";
import { prisma } from "@/lib/prisma";
import { Prisma } from "@prisma/client";

export async function GET(request: NextRequest) {
  try {
    // 1. Validasi session manual
    const cookieStore = await cookies();
    const sessionCookie = cookieStore.get("app_session");

    if (!sessionCookie) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    let session;
    try {
      session = JSON.parse(sessionCookie.value);
    } catch {
      return NextResponse.json({ error: "Invalid session" }, { status: 401 });
    }

    // Check custom role
    const allowedRoles = ["admin", "admin_super", "admin_berkas", "admin_keuangan", "penguji"];
    if (!allowedRoles.includes(session.role)) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    // Get query params
    const searchParams = request.nextUrl.searchParams;
    const page = parseInt(searchParams.get("page") || "1");
    const limit = parseInt(searchParams.get("limit") || "20");
    const search = searchParams.get("search") || "";
    const status = searchParams.get("status") || "";
    const jenjang = searchParams.get("jenjang") || "";
    const tahunAjaran = searchParams.get("tahun_ajaran") || "";
    const provinsi = searchParams.get("provinsi") || "";
    const kabupaten = searchParams.get("kabupaten") || "";
    const kecamatan = searchParams.get("kecamatan") || "";
    const kelurahan = searchParams.get("kelurahan") || "";

    const skip = (page - 1) * limit;

    // Build filter
    const where: Prisma.PendaftarWhereInput = {};

    // Search filter
    if (search) {
      where.OR = [
        { nama_lengkap: { contains: search, mode: "insensitive" } },
        { nik: { contains: search, mode: "insensitive" } },
        { nomor_pendaftaran: { contains: search, mode: "insensitive" } },
      ];
    }

    // Status filter
    if (status) {
      const filterMapping: Record<string, string[]> = {
        belum_bayar: ["draft"],
        menunggu_verifikasi_pembayaran: ["payment_verification"],
        sudah_bayar: ["verified", "scheduled", "accepted"],
        pembayaran_ditolak: ["rejected"],
        belum_isi_data: ["verified"],
        sudah_isi_data: ["scheduled", "accepted"],
        belum_upload_dokumen: ["verified"],
        menunggu_verifikasi_dokumen: [],
        dokumen_terverifikasi: ["scheduled", "accepted"],
        dokumen_ditolak: [],
        terjadwal_ujian: ["scheduled"],
        belum_ujian: ["scheduled"],
        sudah_ujian: ["accepted"],
        hasil_ujian: ["accepted"],
        diterima: ["accepted"],
        belum_daftar_ulang: ["accepted"],
        sudah_daftar_ulang: [],
      };

      const statusValues = filterMapping[status];
      if (statusValues && statusValues.length > 0) {
        where.status_pendaftaran = { in: statusValues };
      } else {
        where.status_pendaftaran = status;
      }
    }

    // Other filters
    if (jenjang) where.jenjang = jenjang;
    if (tahunAjaran) where.tahun_ajaran_id = tahunAjaran;
    if (provinsi) where.provinsi = provinsi;
    if (kabupaten) where.kabupaten = kabupaten;
    if (kecamatan) where.kecamatan = kecamatan;
    if (kelurahan) where.kelurahan = kelurahan;

    // Execute query with transaction for count and data
    const [total, data] = await prisma.$transaction([
      prisma.pendaftar.count({ where }),
      prisma.pendaftar.findMany({
        where,
        select: {
          id: true,
          nomor_pendaftaran: true,
          nik: true,
          nama_lengkap: true,
          jenis_kelamin: true,
          jenjang: true,
          tanggal_lahir: true,
          no_hp: true,
          email: true,
          status_pendaftaran: true,
          created_at: true,
          tahun_ajaran: {
            select: { nama: true }
          },
          pembayaran: {
            select: { status_pembayaran: true }
          },
          dokumen: {
            select: { jenis_dokumen: true, is_verified: true }
          },
          nilai_ujian: {
            select: { nilai_total: true }
          }
        },
        orderBy: { created_at: "desc" },
        skip,
        take: limit,
      }),
    ]);

    return NextResponse.json({
      data: data || [],
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error("Error in admin pendaftar list API:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
