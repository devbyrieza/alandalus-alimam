"use client";

import { useState, useEffect } from "react";
import {
  Calendar,
  Clock,
  MapPin,
  User,
  FileText,
  AlertCircle,
  Loader2,
  CheckCircle,
  Download,
} from "lucide-react";

interface JadwalUjian {
  id: string;
  jenis_ujian: string;
  tanggal_ujian: string;
  waktu_mulai: string;
  waktu_selesai: string | null;
  lokasi: string | null;
  keterangan: string | null;
}

export default function UndanganSeleksiTab() {
  const [jadwal, setJadwal] = useState<JadwalUjian[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchJadwal();
  }, []);

  const fetchJadwal = async () => {
    try {
      setLoading(true);
      // This API needs to be created
      const response = await fetch("/api/pendaftar/jadwal-ujian");
      if (response.ok) {
        const result = await response.json();
        setJadwal(result.data || []);
      }
    } catch (error) {
      console.error("Error fetching jadwal:", error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("id-ID", {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric",
    });
  };

  const formatTime = (timeString: string) => {
    return timeString.substring(0, 5); // HH:MM
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-teal-600 mx-auto mb-4" />
          <p className="text-stone-600">Memuat jadwal ujian...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-500 to-indigo-600 rounded-2xl p-6 text-white">
        <h1 className="text-2xl font-black mb-2">Undangan Seleksi</h1>
        <p className="text-purple-100">
          Jadwal ujian seleksi calon santri baru
        </p>
      </div>

      {jadwal.length === 0 ? (
        <div className="bg-white rounded-xl p-12 border-2 border-stone-200 shadow-sm">
          <div className="text-center">
            <div className="w-20 h-20 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Calendar className="w-10 h-10 text-amber-600" />
            </div>
            <h3 className="text-xl font-bold text-stone-900 mb-3">
              Belum Ada Jadwal Ujian
            </h3>
            <p className="text-stone-600 max-w-md mx-auto">
              Jadwal ujian Anda akan muncul di sini setelah dokumen Anda
              diverifikasi oleh panitia. Mohon tunggu konfirmasi lebih lanjut.
            </p>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          {jadwal.map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-xl shadow-lg p-6 border-2 border-purple-100 hover:border-purple-300 transition-colors"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-purple-100 rounded-xl">
                    <FileText className="w-6 h-6 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-stone-900">
                      {item.jenis_ujian}
                    </h3>
                    <span className="text-sm text-green-600 font-medium flex items-center gap-1 mt-1">
                      <CheckCircle className="w-4 h-4" />
                      Terjadwal
                    </span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center gap-3">
                  <Calendar className="w-5 h-5 text-purple-600" />
                  <div>
                    <p className="text-xs text-stone-500">Tanggal</p>
                    <p className="font-bold text-stone-900">
                      {formatDate(item.tanggal_ujian)}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-purple-600" />
                  <div>
                    <p className="text-xs text-stone-500">Waktu</p>
                    <p className="font-bold text-stone-900">
                      {formatTime(item.waktu_mulai)}
                      {item.waktu_selesai &&
                        ` - ${formatTime(item.waktu_selesai)}`}{" "}
                      WIB
                    </p>
                  </div>
                </div>

                {item.lokasi && (
                  <div className="flex items-center gap-3 md:col-span-2">
                    <MapPin className="w-5 h-5 text-purple-600" />
                    <div>
                      <p className="text-xs text-stone-500">Lokasi</p>
                      <p className="font-bold text-stone-900">{item.lokasi}</p>
                    </div>
                  </div>
                )}

                {item.keterangan && (
                  <div className="md:col-span-2 mt-2 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="text-sm text-blue-900">
                      <strong>Keterangan:</strong> {item.keterangan}
                    </p>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Info Box */}
      <div className="bg-amber-50 border-2 border-amber-200 rounded-xl p-6">
        <div className="flex gap-4">
          <div className="flex-shrink-0">
            <div className="p-2 bg-amber-200 rounded-lg">
              <AlertCircle className="w-6 h-6 text-amber-700" />
            </div>
          </div>
          <div>
            <h4 className="font-bold text-amber-900 mb-2">
              Persiapan Ujian
            </h4>
            <ul className="text-sm text-amber-800 space-y-1">
              <li>• Hadir 30 menit sebelum ujian dimulai</li>
              <li>• Bawa kartu ujian dan identitas diri (KTP/Kartu Pelajar)</li>
              <li>• Kenakan pakaian yang rapi dan sopan</li>
              <li>• Bawa alat tulis (pulpen, pensil, penghapus)</li>
              <li>• Jaga kesehatan dan istirahat yang cukup</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
