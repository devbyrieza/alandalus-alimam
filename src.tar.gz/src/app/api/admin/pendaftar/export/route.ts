import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";
import { prisma } from "@/lib/prisma";
import { Prisma } from "@prisma/client";

export async function GET(req: NextRequest) {
  try {
    // 1. Validasi session manual
    const cookieStore = await cookies();
    const sessionCookie = cookieStore.get("app_session");

    if (!sessionCookie) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    let session;
    try {
      session = JSON.parse(sessionCookie.value);
    } catch {
      return NextResponse.json({ error: "Invalid session" }, { status: 401 });
    }

    // Check custom role
    const allowedRoles = ["admin", "admin_super", "admin_berkas", "admin_keuangan"];
    if (!allowedRoles.includes(session.role)) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const searchParams = req.nextUrl.searchParams;
    const search = searchParams.get("search") || "";
    const status = searchParams.get("status") || "";
    const jenjang = searchParams.get("jenjang") || "";
    const tahunAjaran = searchParams.get("tahun_ajaran") || "";
    const provinsi = searchParams.get("provinsi") || "";
    const kabupaten = searchParams.get("kabupaten") || "";
    const kecamatan = searchParams.get("kecamatan") || "";
    const kelurahan = searchParams.get("kelurahan") || "";

    // Build query - fetch ALL records (no pagination for export)
    const where: Prisma.PendaftarWhereInput = {};

    // Search filter
    if (search) {
      where.OR = [
        { nama_lengkap: { contains: search, mode: "insensitive" } },
        { nik: { contains: search, mode: "insensitive" } },
        { nomor_pendaftaran: { contains: search, mode: "insensitive" } },
      ];
    }

    if (status) query_status(status, where);
    if (jenjang) where.jenjang = jenjang;
    if (tahunAjaran) where.tahun_ajaran_id = tahunAjaran;
    if (provinsi) where.provinsi = provinsi;
    if (kabupaten) where.kabupaten = kabupaten;
    if (kecamatan) where.kecamatan = kecamatan;
    if (kelurahan) where.kelurahan = kelurahan;

    const pendaftarData = await prisma.pendaftar.findMany({
      where,
      select: {
        id: true,
        nomor_pendaftaran: true,
        nik: true,
        nama_lengkap: true,
        jenis_kelamin: true,
        tempat_lahir: true,
        tanggal_lahir: true,
        jenjang: true,
        asal_sekolah: true,
        alamat: true,
        kelurahan: true,
        kecamatan: true,
        kabupaten: true, // mapped to kota_kabupaten in export
        provinsi: true,
        kode_pos: true,
        no_hp: true,
        email: true,
        status_pendaftaran: true,
        created_at: true,
        tahun_ajaran: {
          select: { nama: true }
        }
      },
      orderBy: { created_at: "desc" },
    });

    // Convert to CSV
    const headers = [
      "Nomor Pendaftaran",
      "NIK",
      "Nama Lengkap",
      "Jenis Kelamin",
      "Tempat Lahir",
      "Tanggal Lahir",
      "Jenjang",
      "Asal Sekolah",
      "Alamat",
      "Kelurahan",
      "Kecamatan",
      "Kota/Kabupaten",
      "Provinsi",
      "Kode Pos",
      "No HP",
      "Email",
      "Status",
      "Tahun Ajaran",
      "Tanggal Daftar",
    ];

    const csvRows = [headers.join(",")];

    for (const item of pendaftarData) {
      const row = [
        item.nomor_pendaftaran || "",
        item.nik || "",
        `"${(item.nama_lengkap || "").replace(/"/g, '""')}"`,
        item.jenis_kelamin === "L" ? "Laki-laki" : "Perempuan",
        `"${(item.tempat_lahir || "").replace(/"/g, '""')}"`,
        item.tanggal_lahir ? new Date(item.tanggal_lahir).toLocaleDateString("id-ID") : "",
        item.jenjang || "",
        `"${(item.asal_sekolah || "").replace(/"/g, '""')}"`,
        `"${(item.alamat || "").replace(/"/g, '""')}"`,
        `"${(item.kelurahan || "").replace(/"/g, '""')}"`,
        `"${(item.kecamatan || "").replace(/"/g, '""')}"`,
        `"${(item.kabupaten || "").replace(/"/g, '""')}"`,
        `"${(item.provinsi || "").replace(/"/g, '""')}"`,
        item.kode_pos || "",
        item.no_hp || "",
        item.email || "",
        item.status_pendaftaran || "",
        item.tahun_ajaran?.nama || "",
        item.created_at
          ? new Date(item.created_at).toLocaleDateString("id-ID")
          : "",
      ];
      csvRows.push(row.join(","));
    }

    const csvContent = csvRows.join("\n");

    // Add BOM
    const bom = "\uFEFF";
    const csvWithBom = bom + csvContent;

    // Return as downloadable CSV file
    return new NextResponse(csvWithBom, {
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="pendaftar-${new Date()
          .toISOString()
          .split("T")[0]}.csv"`,
      },
    });
  } catch (error) {
    console.error("Export error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

function query_status(status: string, where: any) {
  // Reuse status mapping logic from pendaftar list if needed, 
  // or just direct match if status is simple.
  // Assuming simple status match for export unless complex filtering is needed.
  // If complex:
  const filterMapping: Record<string, string[]> = {
    // Pembayaran
    belum_bayar: ["draft"],
    menunggu_verifikasi_pembayaran: ["payment_verification"],
    sudah_bayar: ["verified", "scheduled", "accepted"],
    pembayaran_ditolak: ["rejected"],
    // ... (can include others if needed)
  };

  if (filterMapping[status]) {
    where.status_pendaftaran = { in: filterMapping[status] };
  } else {
    where.status_pendaftaran = status;
  }
}
